import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { 
  CheckCircle, Clock, AlertTriangle, Upload, Plus, 
  ExternalLink, Lock, Sparkles, Award, Search, 
  CheckCircle2, XCircle, FileText, Send, Loader2, ChevronDown, ChevronUp, ArrowRight, ArrowLeft, Key,
  Building2, Copy, Calendar, Layers, Zap, ListChecks, Check, ShieldCheck, Filter, Eye, Download, RefreshCw,
  ArrowUpRight, LayoutGrid
} from 'lucide-react';
import { API_URL, BASE_URL } from '../apiConfig';
import { SubmitEvidenceModal } from '../components/SubmitEvidenceModal';
import { ViewProofModal } from '../components/ViewProofModal';
import { AddItemModal } from '../components/AddItemModal';
import { EscalateModal } from '../components/EscalateModal';
import { RejectModal } from '../components/RejectModal';
import { WeeklyPlanner } from '../components/WeeklyPlanner';

import { BRDViewerModal } from '../components/BRDViewerModal';

export const ProjectDashboard = ({ onOpenCopilot }) => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [project, setProject] = useState(null);
  const [checklist, setChecklist] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [onlyCritical, setOnlyCritical] = useState(false);
  const [expandedItemId, setExpandedItemId] = useState(null);
  const [dashboardView, setDashboardView] = useState('SIMPLE'); // 'SIMPLE' | 'MATRIX' | 'PLANNER'

  // Modals & UI action states
  const [submitModalItem, setSubmitModalItem] = useState(null);
  const [viewProofModalItem, setViewProofModalItem] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isBrdModalOpen, setIsBrdModalOpen] = useState(false);
  const [escalateModalItem, setEscalateModalItem] = useState(null);
  const [rejectModalItem, setRejectModalItem] = useState(null);
  const [fetchError, setFetchError] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [internalSignoffLoading, setInternalSignoffLoading] = useState(false);
  const [verifyingId, setVerifyingId] = useState(null);
  const [reanalyzing, setReanalyzing] = useState(false);

  const handleRetryAnalysis = async () => {
    if (reanalyzing) return;
    setReanalyzing(true);
    try {
      const res = await axios.post(`${API_URL}/projects/${id}/retry-analysis`, {});
      alert(`✅ Reanalysis complete: ${res.data.checklist_count} evidence-backed prerequisites extracted.`);
      await fetchProjectData();
    } catch (err) {
      console.error("Retry analysis error:", err);
      const errMsg = err.response?.data?.detail || err.message || "Failed to reanalyze SOW.";
      alert(`⚠️ Reanalysis failed: ${errMsg}`);
      await fetchProjectData();
    } finally {
      setReanalyzing(false);
    }
  };

  const fetchProjectData = async (retryCount = 0) => {
    try {
      const [projRes, checkRes] = await Promise.all([
        axios.get(`${API_URL}/projects/${id}`),
        axios.get(`${API_URL}/projects/${id}/checklist`)
      ]);
      setProject(projRes.data);
      setChecklist(Array.isArray(checkRes.data) ? checkRes.data : []);
      setFetchError(false);
      setLoading(false);
    } catch (err) {
      if (axios.isCancel(err) || err.name === 'CanceledError' || err.code === 'ERR_CANCELED') {
        return;
      }
      console.warn(`Error fetching project data (attempt ${retryCount + 1}):`, err);
      
      // Auto-retry up to 3 times in case of DB sync delay after document upload
      if (retryCount < 3) {
        setTimeout(() => {
          fetchProjectData(retryCount + 1);
        }, 600 * (retryCount + 1));
        return;
      }
      setFetchError(true);
      setLoading(false);
    }
  };

  const handleInternalSignoff = async () => {
    if (!window.confirm("Confirm Akshay & Thasleema internal governance sign-off? This validates that the Pre-Req Tracker has been strictly reviewed without unnecessary filler, and is now cleared for external engagement.")) {
      return;
    }
    setInternalSignoffLoading(true);
    try {
      const res = await axios.post(`${API_URL}/projects/${id}/internal-review-signoff`, {
        reviewer: "Akshay & Thasleema",
        action: "Approve",
        notes: "Pre-Req Tracker verified internally according to minimal standard format."
      });
      setProject(res.data);
      alert("✅ Internal Governance Sign-off complete! Tracker is verified and approved by Akshay & Thasleema.");
    } catch (err) {
      console.error("Signoff error:", err);
      alert("Failed to complete internal sign-off.");
    } finally {
      setInternalSignoffLoading(false);
    }
  };

  const isInternalApproved = project?.internal_review_status?.includes("Approved");

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setFetchError(false);
    fetchProjectData();

    const interval = setInterval(() => {
      if (isMounted && !fetchError) {
        fetchProjectData(0);
      }
    }, 3000);

    const onFocus = () => {
      if (isMounted) fetchProjectData(0);
    };
    window.addEventListener('focus', onFocus);

    return () => {
      isMounted = false;
      clearInterval(interval);
      window.removeEventListener('focus', onFocus);
    };
  }, [id]);

  const handleManualVerify = async (itemId) => {
    try {
      await axios.post(`${API_URL}/items/${itemId}/verify`);
      fetchProjectData();
    } catch (err) {
      alert(err.response?.data?.detail || 'Verification failed');
    }
  };

  const handleToggleCheck = async (e, item) => {
    e?.stopPropagation();
    const nextStatus = item.status === 'Verified' ? 'Pending' : 'Verified';
    try {
      await axios.put(`${API_URL}/items/${item.id}`, { status: nextStatus });
      fetchProjectData();
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.detail || 'Failed to update milestone status');
    }
  };

  const handleAiVerify = async (itemId) => {
    setVerifyingId(itemId);
    try {
      await axios.post(`${API_URL}/items/${itemId}/ai-verify`);
      fetchProjectData();
    } catch (err) {
      alert(err.response?.data?.detail || 'AI verification failed');
    } finally {
      setVerifyingId(null);
    }
  };

  if (loading || (!project && !fetchError)) {
    return (
      <div style={{ background: '#FBFBFC', minHeight: '100vh', paddingBottom: '4rem' }}>
        {/* Workspace Header Skeleton */}
        <section style={{ background: '#ffffff', paddingTop: '1.5rem', paddingBottom: '1.5rem', borderBottom: '1px solid #E2E8F0' }}>
          <div className="goml-container">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
              <div className="goml-skeleton" style={{ width: '160px', height: '18px', borderRadius: '6px' }} />
              <div className="goml-skeleton" style={{ width: '130px', height: '26px', borderRadius: '9999px' }} />
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1.25rem' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '0.65rem' }}>
                  <div className="goml-skeleton" style={{ width: '280px', height: '32px', borderRadius: '8px' }} />
                  <div className="goml-skeleton" style={{ width: '110px', height: '24px', borderRadius: '9999px' }} />
                </div>
                <div style={{ display: 'flex', gap: '8px', marginTop: '0.5rem' }}>
                  <div className="goml-skeleton" style={{ width: '130px', height: '22px', borderRadius: '6px' }} />
                  <div className="goml-skeleton" style={{ width: '160px', height: '22px', borderRadius: '6px' }} />
                  <div className="goml-skeleton" style={{ width: '110px', height: '22px', borderRadius: '6px' }} />
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <div className="goml-skeleton" style={{ width: '180px', height: '38px', borderRadius: '9999px' }} />
                <div className="goml-skeleton" style={{ width: '150px', height: '38px', borderRadius: '9999px' }} />
              </div>
            </div>
          </div>
        </section>

        {/* KPI Scorecard Grid Skeleton */}
        <section style={{ paddingTop: '1.75rem', paddingBottom: '1rem' }}>
          <div className="goml-container">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
              {[1, 2, 3, 4].map(idx => (
                <div key={idx} style={{ background: '#FFFFFF', border: '1px solid #E2E8F0', borderRadius: '14px', padding: '1.35rem 1.5rem' }}>
                  <div className="goml-skeleton" style={{ width: '100px', height: '14px', borderRadius: '4px', marginBottom: '12px' }} />
                  <div className="goml-skeleton" style={{ width: '80px', height: '36px', borderRadius: '6px', marginBottom: '8px' }} />
                  <div className="goml-skeleton" style={{ width: '140px', height: '12px', borderRadius: '4px' }} />
                </div>
              ))}
            </div>

            {/* Verification Table & Filter Skeleton */}
            <div style={{ background: '#FFFFFF', border: '1px solid #E2E8F0', borderRadius: '16px', padding: '1.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.02)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '1rem' }}>
                <div className="goml-skeleton" style={{ width: '220px', height: '24px', borderRadius: '6px' }} />
                <div style={{ display: 'flex', gap: '8px' }}>
                  <div className="goml-skeleton" style={{ width: '90px', height: '32px', borderRadius: '8px' }} />
                  <div className="goml-skeleton" style={{ width: '90px', height: '32px', borderRadius: '8px' }} />
                  <div className="goml-skeleton" style={{ width: '90px', height: '32px', borderRadius: '8px' }} />
                </div>
              </div>

              {/* Table Rows Skeleton */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {[1, 2, 3, 4, 5].map(rowIdx => (
                  <div key={rowIdx} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px', background: '#F8FAFC', borderRadius: '10px', border: '1px solid #F1F5F9' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div className="goml-skeleton" style={{ width: '20px', height: '20px', borderRadius: '50%' }} />
                      <div>
                        <div className="goml-skeleton" style={{ width: `${180 + (rowIdx * 35)}px`, height: '16px', borderRadius: '4px', marginBottom: '6px' }} />
                        <div className="goml-skeleton" style={{ width: '140px', height: '12px', borderRadius: '4px' }} />
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div className="goml-skeleton" style={{ width: '90px', height: '24px', borderRadius: '9999px' }} />
                      <div className="goml-skeleton" style={{ width: '80px', height: '32px', borderRadius: '8px' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }

  if (!project || fetchError) {
    return (
      <div className="goml-container" style={{ padding: '6rem 1rem', textAlign: 'center', maxWidth: '600px', margin: '0 auto' }}>
        <div style={{ width: '56px', height: '56px', borderRadius: '16px', background: '#FFF7ED', border: '1px solid #FFEDD5', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.25rem' }}>
          <AlertTriangle size={28} color="#ED7D31" />
        </div>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0F172A', margin: 0 }}>Initiative Workspace Sync Pending</h2>
        <p style={{ color: '#64748B', fontSize: '13.5px', marginTop: '0.6rem', lineHeight: 1.6 }}>
          The requested project workspace (<code style={{ background: '#F1F5F9', padding: '2px 6px', borderRadius: '4px', fontSize: '12px' }}>{id?.slice(0, 12)}...</code>) is finalizing setup or experienced a brief sync delay.
        </p>
        <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', marginTop: '1.75rem', flexWrap: 'wrap' }}>
          <button 
            onClick={() => {
              setLoading(true);
              setFetchError(false);
              fetchProjectData(0);
            }} 
            style={{
              background: '#ED7D31',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '9999px',
              padding: '9px 20px',
              fontSize: '13px',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              boxShadow: '0 2px 8px rgba(237, 125, 49, 0.3)'
            }}
          >
            <RefreshCw size={14} />
            <span>Retry Workspace Load</span>
          </button>

          <button 
            onClick={() => navigate('/')} 
            style={{
              background: '#000000',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '9999px',
              padding: '9px 20px',
              fontSize: '13px',
              fontWeight: 700,
              cursor: 'pointer'
            }}
          >
            Return to Executive Portfolio
          </button>
        </div>
      </div>
    );
  }

  const safeChecklist = Array.isArray(checklist) ? checklist : [];

  const categories = Array.from(new Set(safeChecklist.map(i => i?.category || 'General')));

  const filteredItems = safeChecklist.filter(item => {
    if (!item) return false;
    const nameStr = (item.name || '').toLowerCase();
    const descStr = (item.description || '').toLowerCase();
    const ownerStr = (item.owner || '').toLowerCase();
    const query = (search || '').toLowerCase();

    const matchesSearch = nameStr.includes(query) ||
                          descStr.includes(query) ||
                          ownerStr.includes(query);
    const matchesCategory = selectedCategory === 'ALL' || item.category === selectedCategory;
    const matchesStatus = selectedStatus === 'ALL' ||
      (selectedStatus === 'LOCKED' && item.is_locked) ||
      (item.status === selectedStatus);
    const matchesCritical = !onlyCritical || item.is_critical;

    return matchesSearch && matchesCategory && matchesStatus && matchesCritical;
  });

  const getStatusBadge = (status) => {
    if (status === 'Kick-off Cleared') {
      return (
        <span style={{
          background: '#F0FDF4',
          color: '#166534',
          border: '1px solid #BBF7D0',
          padding: '4px 12px',
          borderRadius: '9999px',
          fontSize: '11px',
          fontWeight: 700,
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px'
        }}>
          <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#16A34A', display: 'inline-block' }} />
          <span>Cleared for Kick-off</span>
        </span>
      );
    }
    if (status === 'Critical / Blocked') {
      return (
        <span style={{
          background: '#FEF2F2',
          color: '#DC2626',
          border: '1px solid #FECACA',
          padding: '4px 12px',
          borderRadius: '9999px',
          fontSize: '11px',
          fontWeight: 700,
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px'
        }}>
          <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#DC2626', display: 'inline-block' }} />
          <span>Critical Blocker</span>
        </span>
      );
    }
    if (status === 'At Risk') {
      return (
        <span style={{
          background: '#FFF7ED',
          color: '#C2410C',
          border: '1px solid #FFEDD5',
          padding: '4px 12px',
          borderRadius: '9999px',
          fontSize: '11px',
          fontWeight: 700,
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px'
        }}>
          <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#ED7D31', display: 'inline-block' }} />
          <span>At Risk</span>
        </span>
      );
    }
    return (
      <span style={{
        background: '#F1F5F9',
        color: '#475569',
        border: '1px solid #E2E8F0',
        padding: '4px 12px',
        borderRadius: '9999px',
        fontSize: '11px',
        fontWeight: 600,
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px'
      }}>
        <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#64748B', display: 'inline-block' }} />
        <span>In Progress</span>
      </span>
    );
  };

  const blockersCount = safeChecklist.filter(i => i?.is_critical && i?.status !== 'Verified').length;
  const lockedCount = safeChecklist.filter(i => i?.is_locked).length;
  const inReviewCount = safeChecklist.filter(i => i?.status === 'Submitted' || i?.status === 'Verifying').length;
  const verifiedCount = safeChecklist.filter(i => i?.status === 'Verified').length;
  const pendingCount = safeChecklist.filter(i => i?.status !== 'Verified').length;

  return (
    <div style={{ background: '#F4F5F7', minHeight: '100vh', paddingBottom: '5rem' }}>
      {/* Top Workspace Header Bar */}
      <section style={{ background: '#FFFFFF', paddingTop: '1.25rem', paddingBottom: '1.25rem', borderBottom: '1px solid rgba(226, 232, 240, 0.8)' }}>
        <div className="goml-container">
          {/* Breadcrumb & Client Link */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem', flexWrap: 'wrap', gap: '0.75rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12.5px', color: '#64748B' }}>
              <Link
                to="/portfolio"
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '5px',
                  color: '#64748B',
                  textDecoration: 'none',
                  fontWeight: 600,
                  transition: 'color 0.15s ease'
                }}
                onMouseOver={(e) => { e.currentTarget.style.color = '#ED7D31'; }}
                onMouseOut={(e) => { e.currentTarget.style.color = '#64748B'; }}
                title="Return to Executive Portfolio"
              >
                <ArrowLeft size={13} strokeWidth={2.2} />
                <span>Portfolio</span>
              </Link>
              <span style={{ color: '#CBD5E1' }}>/</span>
              <span style={{ color: '#0F172A', fontWeight: 600 }}>{project.client_name}</span>
              <span style={{ color: '#CBD5E1' }}>/</span>
              <span>Readiness Audit & Delivery Workspace</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '12px', color: '#64748B', fontWeight: 500 }}>Client Portal:</span>
              <button
                type="button"
                onClick={() => {
                  const clientUrl = `${window.location.origin}/client/${id}`;
                  navigator.clipboard.writeText(clientUrl);
                  setCopiedLink(true);
                  setTimeout(() => setCopiedLink(false), 2200);
                }}
                style={{
                  background: copiedLink ? '#DCFCE7' : '#FFFFFF',
                  color: copiedLink ? '#166534' : '#334155',
                  border: '1px solid',
                  borderColor: copiedLink ? '#86EFAC' : '#E2E8F0',
                  borderRadius: '9999px',
                  padding: '5px 14px',
                  fontSize: '12px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                  transition: 'all 0.15s ease'
                }}
                title="Copy client-facing self-service URL"
              >
                {copiedLink ? <Check size={13} color="#166534" /> : <Copy size={13} />}
                <span>{copiedLink ? 'Link Copied!' : 'Copy Portal Link'}</span>
              </button>
            </div>
          </div>

          {/* Project Title & Action Pill Buttons */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1.25rem' }}>
            <div style={{ maxWidth: '720px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap', marginBottom: '0.4rem' }}>
                <h1 style={{ fontSize: '1.95rem', fontWeight: 800, margin: 0, color: '#0F172A', letterSpacing: '-0.025em', lineHeight: 1.2 }}>
                  {project.name}
                </h1>
                {getStatusBadge(project.status)}
              </div>

              {/* Clean Inline Metadata Chips */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap', fontSize: '13px', color: '#64748B', marginTop: '0.35rem' }}>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', color: '#334155' }}>
                  <Building2 size={14} color="#ED7D31" />
                  <span style={{ color: '#64748B' }}>Client:</span>
                  <strong style={{ color: '#0F172A', fontWeight: 700 }}>{project.client_name}</strong>
                </span>

                <span style={{ color: '#CBD5E1' }}>•</span>

                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', color: '#475569' }}>
                  <Layers size={14} color="#64748B" />
                  <span style={{ color: '#64748B' }}>Type:</span>
                  <span style={{ color: '#0F172A', fontWeight: 600 }}>{project.type}</span>
                </span>

                <span style={{ color: '#CBD5E1' }}>•</span>

                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', color: '#475569' }}>
                  <Calendar size={14} color="#64748B" />
                  <span style={{ color: '#64748B' }}>Kick-off:</span>
                  <strong style={{ color: '#0F172A', fontWeight: 700 }}>{project.target_kickoff_date || 'TBD'}</strong>
                </span>

                {project.deployment && (
                  <>
                    <span style={{ color: '#CBD5E1' }}>•</span>
                    <span style={{
                      background: '#FFF7ED',
                      color: '#C2410C',
                      border: '1px solid #FFEDD5',
                      padding: '2px 10px',
                      borderRadius: '9999px',
                      fontSize: '11.5px',
                      fontWeight: 700
                    }}>
                      {project.deployment}
                    </span>
                  </>
                )}

                {project.industry && (
                  <>
                    <span style={{ color: '#CBD5E1' }}>•</span>
                    <span style={{
                      background: '#F1F5F9',
                      color: '#475569',
                      border: '1px solid #E2E8F0',
                      padding: '2px 10px',
                      borderRadius: '9999px',
                      fontSize: '11.5px',
                      fontWeight: 600
                    }}>
                      {project.industry}
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* Clean Cohesive Action Pill Buttons */}
            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
              <button
                type="button"
                onClick={() => setIsBrdModalOpen(true)}
                style={{
                  background: '#FFFFFF',
                  color: '#0F172A',
                  border: '1px solid #E2E8F0',
                  borderRadius: '9999px',
                  height: '36px',
                  padding: '0 16px',
                  fontSize: '12.5px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '7px',
                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                  transition: 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = '#F8FAFC';
                  e.currentTarget.style.borderColor = '#CBD5E1';
                  e.currentTarget.style.boxShadow = '0 2px 6px rgba(15, 23, 42, 0.07)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = '#FFFFFF';
                  e.currentTarget.style.borderColor = '#E2E8F0';
                  e.currentTarget.style.boxShadow = '0 1px 2px rgba(15, 23, 42, 0.04)';
                }}
                title="View interactive 27-Section Business Requirements Document"
              >
                <FileText size={14} color="#64748B" strokeWidth={2.2} />
                <span>View BRD</span>
                <span style={{
                  background: '#F1F5F9',
                  color: '#475569',
                  fontSize: '11px',
                  fontWeight: 700,
                  padding: '1px 7px',
                  borderRadius: '9999px',
                  letterSpacing: '0.01em'
                }}>
                  27 Sections
                </span>
              </button>

              <a
                href={`${API_URL}/projects/${id}/export-excel-tracker`}
                target="_blank"
                rel="noreferrer"
                style={{
                  background: '#FFFFFF',
                  color: '#0F172A',
                  border: '1px solid #E2E8F0',
                  borderRadius: '9999px',
                  height: '36px',
                  padding: '0 16px',
                  fontSize: '12.5px',
                  fontWeight: 600,
                  textDecoration: 'none',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '7px',
                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                  transition: 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = '#F8FAFC';
                  e.currentTarget.style.borderColor = '#CBD5E1';
                  e.currentTarget.style.boxShadow = '0 2px 6px rgba(15, 23, 42, 0.07)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = '#FFFFFF';
                  e.currentTarget.style.borderColor = '#E2E8F0';
                  e.currentTarget.style.boxShadow = '0 1px 2px rgba(15, 23, 42, 0.04)';
                }}
                title="Download minimal Excel Pre-Req Tracker"
              >
                <Download size={13} strokeWidth={2.2} color="#64748B" />
                <span>Tracker (.xlsx)</span>
              </a>

              <a
                href={`${API_URL}/projects/${id}/export-brd-docx`}
                target="_blank"
                rel="noreferrer"
                style={{
                  background: '#FFFFFF',
                  color: '#0F172A',
                  border: '1px solid #E2E8F0',
                  borderRadius: '9999px',
                  height: '36px',
                  padding: '0 16px',
                  fontSize: '12.5px',
                  fontWeight: 600,
                  textDecoration: 'none',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '7px',
                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                  transition: 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = '#F8FAFC';
                  e.currentTarget.style.borderColor = '#CBD5E1';
                  e.currentTarget.style.boxShadow = '0 2px 6px rgba(15, 23, 42, 0.07)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = '#FFFFFF';
                  e.currentTarget.style.borderColor = '#E2E8F0';
                  e.currentTarget.style.boxShadow = '0 1px 2px rgba(15, 23, 42, 0.04)';
                }}
                title="Download formatted Word BRD Document"
              >
                <Download size={13} strokeWidth={2.2} color="#64748B" />
                <span>BRD (.docx)</span>
              </a>

              <Link
                to={`/client/${id}`}
                target="_blank"
                style={{
                  background: '#FFFFFF',
                  color: '#0F172A',
                  border: '1px solid #E2E8F0',
                  borderRadius: '9999px',
                  height: '36px',
                  padding: '0 16px',
                  fontSize: '12.5px',
                  fontWeight: 600,
                  textDecoration: 'none',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '7px',
                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                  transition: 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = '#F8FAFC';
                  e.currentTarget.style.borderColor = '#CBD5E1';
                  e.currentTarget.style.boxShadow = '0 2px 6px rgba(15, 23, 42, 0.07)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = '#FFFFFF';
                  e.currentTarget.style.borderColor = '#E2E8F0';
                  e.currentTarget.style.boxShadow = '0 1px 2px rgba(15, 23, 42, 0.04)';
                }}
              >
                <ExternalLink size={13} strokeWidth={2.2} color="#64748B" />
                <span>Client Portal</span>
              </Link>

              {project.score >= 90 && blockersCount === 0 && (
                <button
                  type="button"
                  onClick={() => navigate(`/certificate/${id}`)}
                  style={{
                    background: '#FFFFFF',
                    color: '#0F172A',
                    border: '1px solid #E2E8F0',
                    borderRadius: '9999px',
                    height: '36px',
                    padding: '0 16px',
                    fontSize: '12.5px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '7px',
                    boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                    transition: 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.background = '#F8FAFC';
                    e.currentTarget.style.borderColor = '#CBD5E1';
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.background = '#FFFFFF';
                    e.currentTarget.style.borderColor = '#E2E8F0';
                  }}
                >
                  <Award size={14} color="#64748B" />
                  <span>Certificate</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleRetryAnalysis}
                disabled={reanalyzing}
                style={{
                  background: '#FFFFFF',
                  color: '#0F172A',
                  border: '1px solid #E2E8F0',
                  borderRadius: '9999px',
                  height: '36px',
                  padding: '0 16px',
                  fontSize: '12.5px',
                  fontWeight: 600,
                  cursor: reanalyzing ? 'not-allowed' : 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '7px',
                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                  transition: 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = '#F8FAFC';
                  e.currentTarget.style.borderColor = '#CBD5E1';
                  e.currentTarget.style.boxShadow = '0 2px 6px rgba(15, 23, 42, 0.07)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = '#FFFFFF';
                  e.currentTarget.style.borderColor = '#E2E8F0';
                  e.currentTarget.style.boxShadow = '0 1px 2px rgba(15, 23, 42, 0.04)';
                }}
                title="Re-run AI extraction on original SOW text"
              >
                <RefreshCw size={13} strokeWidth={2.2} color="#64748B" className={reanalyzing ? 'animate-spin' : ''} />
                <span>{reanalyzing ? 'Reanalyzing...' : 'Reanalyze SOW'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsAddModalOpen(true)}
                style={{
                  background: '#0F172A',
                  color: '#FFFFFF',
                  border: '1px solid #0F172A',
                  borderRadius: '9999px',
                  height: '36px',
                  padding: '0 18px',
                  fontSize: '12.5px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '7px',
                  boxShadow: '0 1px 3px rgba(15, 23, 42, 0.12)',
                  transition: 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = '#1E293B';
                  e.currentTarget.style.borderColor = '#1E293B';
                  e.currentTarget.style.boxShadow = '0 3px 8px rgba(15, 23, 42, 0.2)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = '#0F172A';
                  e.currentTarget.style.borderColor = '#0F172A';
                  e.currentTarget.style.boxShadow = '0 1px 3px rgba(15, 23, 42, 0.12)';
                }}
              >
                <Plus size={14} strokeWidth={2.5} color="#FFFFFF" />
                <span>Add Pre-requisite</span>
              </button>
            </div>
          </div>

          {/* Internal Governance Banner */}
          <div style={{
            marginTop: '1.25rem',
            padding: '0.85rem 1.25rem',
            borderRadius: '16px',
            background: isInternalApproved ? '#F0FDF4' : '#FFFBEB',
            border: '1px solid',
            borderColor: isInternalApproved ? '#BBF7D0' : '#FED7AA',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '12px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{
                width: '34px',
                height: '34px',
                borderRadius: '50%',
                background: isInternalApproved ? '#DCFCE7' : '#FFEDD5',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                <ShieldCheck size={18} color={isInternalApproved ? '#16A34A' : '#EA580C'} />
              </div>
              <div>
                <div style={{ fontSize: '13px', fontWeight: 700, color: isInternalApproved ? '#166534' : '#9A3412', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span>{isInternalApproved ? 'Internal Governance Review: Approved by Akshay & Thasleema' : 'Internal Governance Review: Pending Approval (Akshay & Thasleema)'}</span>
                  <span style={{ fontSize: '10.5px', background: isInternalApproved ? '#DCFCE7' : '#FED7AA', color: isInternalApproved ? '#166534' : '#9A3412', padding: '2px 8px', borderRadius: '9999px', fontWeight: 800 }}>
                    {isInternalApproved ? 'CLEARED' : 'INTERNAL ONLY'}
                  </span>
                </div>
                <div style={{ fontSize: '12px', color: isInternalApproved ? '#15803D' : '#C2410C', marginTop: '2px' }}>
                  {isInternalApproved
                    ? 'The Pre-Req Tracker and 27-Section BRD have been reviewed internally without unnecessary descriptions, and are cleared for client engagement.'
                    : 'The generated tracker must not be sent directly to the client. Akshay and Thasleema will review the generated tracker internally before external distribution.'}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              {!isInternalApproved ? (
                <button
                  type="button"
                  onClick={handleInternalSignoff}
                  disabled={internalSignoffLoading}
                  style={{
                    background: '#0F172A',
                    color: '#FFFFFF',
                    border: 'none',
                    padding: '7px 16px',
                    borderRadius: '9999px',
                    fontSize: '12px',
                    fontWeight: 600,
                    cursor: internalSignoffLoading ? 'not-allowed' : 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    transition: 'all 0.15s ease'
                  }}
                  onMouseOver={(e) => { e.currentTarget.style.background = '#ED7D31'; }}
                  onMouseOut={(e) => { e.currentTarget.style.background = '#0F172A'; }}
                >
                  <ShieldCheck size={14} color="#ED7D31" />
                  <span>{internalSignoffLoading ? 'Signing off...' : 'Sign Off (Akshay & Thasleema)'}</span>
                </button>
              ) : (
                <span style={{ fontSize: '12px', color: '#166534', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: '5px', background: '#DCFCE7', padding: '4px 12px', borderRadius: '9999px' }}>
                  <Check size={14} strokeWidth={3} /> Signed & Cleared
                </span>
              )}
            </div>
          </div>

          {/* SOW Analysis Failed Alert Banner */}
          {(project?.analysis_status === 'FAILED' || project?.status === 'Analysis Failed') && (
            <div style={{
              marginTop: '1rem',
              padding: '0.9rem 1.25rem',
              borderRadius: '16px',
              background: '#FEF2F2',
              border: '1px solid #FECACA',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '12px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.02)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  background: '#FEE2E2',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0
                }}>
                  <AlertTriangle size={18} color="#DC2626" />
                </div>
                <div>
                  <div style={{ fontSize: '13px', fontWeight: 700, color: '#991B1B', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span>SOW Analysis Failed</span>
                    <span style={{ fontSize: '10.5px', background: '#FEE2E2', color: '#991B1B', padding: '2px 8px', borderRadius: '9999px', fontWeight: 800 }}>
                      ACTION REQUIRED
                    </span>
                  </div>
                  <div style={{ fontSize: '12px', color: '#B91C1C', marginTop: '2px', maxWidth: '750px', lineHeight: 1.4 }}>
                    {project.analysis_error || 'The AI model was unable to extract prerequisites from the proposal document.'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleRetryAnalysis}
                disabled={reanalyzing}
                style={{
                  background: '#DC2626',
                  color: '#FFFFFF',
                  border: 'none',
                  padding: '7px 18px',
                  borderRadius: '9999px',
                  fontSize: '12px',
                  fontWeight: 600,
                  cursor: reanalyzing ? 'not-allowed' : 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 1px 3px rgba(220, 38, 38, 0.2)',
                  transition: 'all 0.15s ease'
                }}
                onMouseOver={(e) => { e.currentTarget.style.background = '#B91C1C'; }}
                onMouseOut={(e) => { e.currentTarget.style.background = '#DC2626'; }}
              >
                <RefreshCw size={13} color="#FFFFFF" className={reanalyzing ? 'animate-spin' : ''} />
                <span>{reanalyzing ? 'Reanalyzing...' : 'Retry SOW Analysis'}</span>
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Main Dashboard Canvas: 5-Card Layout from Reference Image */}
      <section style={{ paddingTop: '2rem', paddingBottom: '2.5rem' }}>
        <div className="goml-container">
          {/* Top Overview Row: Title & 4 Horizontal Key Stats & Filter Dropdowns */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-end',
            marginBottom: '1.75rem',
            flexWrap: 'wrap',
            gap: '1.25rem'
          }}>
            <div>
              <h2 style={{ fontSize: '1.75rem', fontWeight: 800, color: '#0F172A', margin: '0 0 1rem 0', letterSpacing: '-0.025em' }}>
                Overview
              </h2>

              {/* 4 Horizontal Key Stats with numbers and pill badges */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '2.5rem', flexWrap: 'wrap' }}>
                {/* Metric 1 */}
                <div>
                  <div style={{ fontSize: '11.5px', color: '#64748B', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '2px' }}>
                    Readiness Index
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '1.85rem', fontWeight: 800, color: '#0F172A', letterSpacing: '-0.03em' }}>
                      {project.score}%
                    </span>
                    <span style={{
                      background: project.score >= 90 ? '#DCFCE7' : '#FFF7ED',
                      color: project.score >= 90 ? '#166534' : '#C2410C',
                      fontSize: '11px',
                      fontWeight: 700,
                      padding: '2px 8px',
                      borderRadius: '9999px'
                    }}>
                      {verifiedCount} Cleared
                    </span>
                  </div>
                </div>

                {/* Metric 2 */}
                <div>
                  <div style={{ fontSize: '11.5px', color: '#64748B', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '2px' }}>
                    Gatekeepers
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '1.85rem', fontWeight: 800, color: blockersCount > 0 ? '#EA580C' : '#0F172A', letterSpacing: '-0.03em' }}>
                      {blockersCount}
                    </span>
                    <span style={{
                      background: blockersCount > 0 ? '#FEF2F2' : '#F0FDF4',
                      color: blockersCount > 0 ? '#DC2626' : '#166534',
                      fontSize: '11px',
                      fontWeight: 700,
                      padding: '2px 8px',
                      borderRadius: '9999px'
                    }}>
                      {blockersCount > 0 ? 'Action Required' : 'All Clear'}
                    </span>
                  </div>
                </div>

                {/* Metric 3 */}
                <div>
                  <div style={{ fontSize: '11.5px', color: '#64748B', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '2px' }}>
                    Ledger Milestones
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '1.85rem', fontWeight: 800, color: '#0F172A', letterSpacing: '-0.03em' }}>
                      {project.total_items}
                    </span>
                    <span style={{
                      background: '#F1F5F9',
                      color: '#475569',
                      fontSize: '11px',
                      fontWeight: 700,
                      padding: '2px 8px',
                      borderRadius: '9999px'
                    }}>
                      {pendingCount} Open
                    </span>
                  </div>
                </div>

                {/* Metric 4 */}
                <div>
                  <div style={{ fontSize: '11.5px', color: '#64748B', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '2px' }}>
                    Target Kick-off
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0F172A', letterSpacing: '-0.02em' }}>
                      {project.target_kickoff_date || 'Day-1 Target'}
                    </span>
                    <span style={{
                      background: '#FFF7ED',
                      color: '#ED7D31',
                      fontSize: '11px',
                      fontWeight: 700,
                      padding: '2px 8px',
                      borderRadius: '9999px'
                    }}>
                      {project.type || 'SOW Initiative'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Pill Filters matching reference image dropdowns */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <button
                type="button"
                onClick={() => setSelectedCategory('ALL')}
                style={{
                  background: '#FFFFFF',
                  color: selectedCategory === 'ALL' ? '#0F172A' : '#475569',
                  border: '1px solid #E2E8F0',
                  borderRadius: '9999px',
                  padding: '7px 16px',
                  fontSize: '12px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)'
                }}
              >
                <Filter size={13} color="#ED7D31" />
                <span>{selectedCategory === 'ALL' ? 'Filter Category' : selectedCategory}</span>
                <ChevronDown size={12} color="#94A3B8" />
              </button>

              <button
                type="button"
                onClick={() => setSelectedStatus(selectedStatus === 'ALL' ? 'Critical' : 'ALL')}
                style={{
                  background: '#FFFFFF',
                  color: '#475569',
                  border: '1px solid #E2E8F0',
                  borderRadius: '9999px',
                  padding: '7px 16px',
                  fontSize: '12px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)'
                }}
              >
                <Calendar size={13} color="#ED7D31" />
                <span>Filter Status</span>
                <ChevronDown size={12} color="#94A3B8" />
              </button>
            </div>
          </div>

          {/* 5-Card Dashboard Grid (Mirrors Layout of Reference Screenshot) */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(12, 1fr)',
            gap: '1.25rem',
            marginBottom: '2.5rem'
          }}>
            {/* CARD 1: Reports / Readiness Trajectory (Spans 8 columns) */}
            <div style={{
              gridColumn: 'span 8',
              background: '#FFFFFF',
              borderRadius: '24px',
              padding: '1.75rem',
              boxShadow: '0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)',
              border: '1px solid rgba(226, 232, 240, 0.8)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              minHeight: '290px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                <div>
                  <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>
                    Reports
                  </h3>
                  <div style={{ display: 'flex', gap: '2rem', marginTop: '0.65rem' }}>
                    <div>
                      <div style={{ fontSize: '11px', color: '#64748B', fontWeight: 600, textTransform: 'uppercase' }}>Cleared</div>
                      <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0F172A' }}>
                        {verifiedCount} <span style={{ fontSize: '12px', color: '#16A34A', fontWeight: 700 }}>milestones</span>
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: '11px', color: '#64748B', fontWeight: 600, textTransform: 'uppercase' }}>Remaining</div>
                      <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#ED7D31' }}>
                        {pendingCount} <span style={{ fontSize: '12px', color: '#ED7D31', fontWeight: 700 }}>milestones</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div style={{
                  background: '#FFFFFF',
                  border: '1px solid #E2E8F0',
                  borderRadius: '9999px',
                  padding: '6px 14px',
                  fontSize: '12px',
                  fontWeight: 600,
                  color: '#475569',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px'
                }}>
                  <span>Weekly</span>
                  <ChevronDown size={12} color="#94A3B8" />
                </div>
              </div>

              {/* Sleek Delivery Trajectory SVG Curve with Tooltip pill */}
              <div style={{ position: 'relative', marginTop: '1rem' }}>
                <svg viewBox="0 0 650 120" style={{ width: '100%', height: '110px', overflow: 'visible' }}>
                  <defs>
                    <linearGradient id="curveGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#ED7D31" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#ED7D31" stopOpacity="0.0" />
                    </linearGradient>
                    <pattern id="diagonalHatch" width="6" height="6" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
                      <line x1="0" y1="0" x2="0" y2="6" style={{ stroke: '#CBD5E1', strokeWidth: 1 }} />
                    </pattern>
                  </defs>

                  {/* Dotted reference line */}
                  <path
                    d="M 20,80 Q 150,95 280,60 T 630,70"
                    fill="none"
                    stroke="#CBD5E1"
                    strokeWidth="1.5"
                    strokeDasharray="4,4"
                  />

                  {/* Primary smooth curve */}
                  <path
                    d="M 20,75 C 120,85 200,95 320,50 C 440,15 540,65 630,60"
                    fill="url(#curveGradient)"
                  />
                  <path
                    d="M 20,75 C 120,85 200,95 320,50 C 440,15 540,65 630,60"
                    fill="none"
                    stroke="#ED7D31"
                    strokeWidth="2.5"
                  />

                  {/* Dot points */}
                  <circle cx="20" cy="75" r="3.5" fill="#ED7D31" />
                  <circle cx="170" cy="88" r="3.5" fill="#ED7D31" />
                  <circle cx="320" cy="50" r="4.5" fill="#FFFFFF" stroke="#ED7D31" strokeWidth="2.5" />
                  <circle cx="475" cy="40" r="3.5" fill="#ED7D31" />
                  <circle cx="630" cy="60" r="3.5" fill="#ED7D31" />
                </svg>

                {/* Floating Tooltip Pill mirroring reference image */}
                <div style={{
                  position: 'absolute',
                  top: '10px',
                  left: '46%',
                  transform: 'translateX(-50%)',
                  background: '#FFFFFF',
                  borderRadius: '16px',
                  padding: '8px 14px',
                  boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
                  border: '1px solid #E2E8F0',
                  fontSize: '11.5px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '2px',
                  zIndex: 2
                }}>
                  <div style={{ color: '#94A3B8', fontSize: '10.5px', fontWeight: 600 }}>Sprint 2 Milestone</div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px' }}>
                    <span style={{ color: '#0F172A', fontWeight: 700 }}>✓ Cleared:</span>
                    <span style={{ color: '#16A34A', fontWeight: 800 }}>{verifiedCount} items</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px' }}>
                    <span style={{ color: '#64748B', fontWeight: 600 }}>◷ Remaining:</span>
                    <span style={{ color: '#ED7D31', fontWeight: 800 }}>{pendingCount} items</span>
                  </div>
                </div>

                {/* Date Labels */}
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#94A3B8', marginTop: '6px', fontWeight: 600 }}>
                  <span>Sprint 1</span>
                  <span>Sprint 2</span>
                  <span>Sprint 3</span>
                  <span>Sprint 4</span>
                  <span>Kick-off Day</span>
                </div>
              </div>
            </div>

            {/* CARD 2: Order Status / Gatekeeper Status (Spans 4 columns) */}
            <div style={{
              gridColumn: 'span 4',
              background: '#FFFFFF',
              borderRadius: '24px',
              padding: '1.75rem',
              boxShadow: '0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)',
              border: '1px solid rgba(226, 232, 240, 0.8)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              minHeight: '290px'
            }}>
              <div>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>
                  Gatekeeper Status
                </h3>

                {/* Subtitle pill card */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  background: '#F8FAFC',
                  borderRadius: '16px',
                  padding: '8px 14px',
                  marginTop: '0.85rem',
                  border: '1px solid #F1F5F9'
                }}>
                  <span style={{ fontSize: '12.5px', color: '#334155', fontWeight: 600 }}>
                    Active Deliverables: <strong style={{ color: '#0F172A' }}>{project.total_items}</strong>
                  </span>
                  <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#FFFFFF', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #E2E8F0' }}>
                    <ArrowUpRight size={13} color="#0F172A" />
                  </div>
                </div>

                {/* 3 Rounded Colored Blocks in goML Orange Palette matching Reference Screenshot */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', marginTop: '1.15rem' }}>
                  {/* Block 1: Dark Terracotta / Critical */}
                  <div style={{
                    height: '68px',
                    borderRadius: '16px',
                    background: 'linear-gradient(135deg, #C2410C 0%, #9A3412 100%)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#FFFFFF',
                    boxShadow: '0 2px 8px rgba(194, 65, 12, 0.2)'
                  }}>
                    <span style={{ fontSize: '1.25rem', fontWeight: 800 }}>{blockersCount}</span>
                    <span style={{ fontSize: '10px', opacity: 0.9, fontWeight: 700 }}>Blockers</span>
                  </div>

                  {/* Block 2: Brand Orange / In Review */}
                  <div style={{
                    height: '68px',
                    borderRadius: '16px',
                    background: 'linear-gradient(135deg, #ED7D31 0%, #EA580C 100%)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#FFFFFF',
                    boxShadow: '0 2px 8px rgba(237, 125, 49, 0.2)'
                  }}>
                    <span style={{ fontSize: '1.25rem', fontWeight: 800 }}>{inReviewCount}</span>
                    <span style={{ fontSize: '10px', opacity: 0.9, fontWeight: 700 }}>In Review</span>
                  </div>

                  {/* Block 3: Warm Peach / Cleared */}
                  <div style={{
                    height: '68px',
                    borderRadius: '16px',
                    background: 'linear-gradient(135deg, #FDBA74 0%, #FB923C 100%)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#0F172A',
                    boxShadow: '0 2px 8px rgba(251, 146, 60, 0.15)'
                  }}>
                    <span style={{ fontSize: '1.25rem', fontWeight: 800 }}>{verifiedCount}</span>
                    <span style={{ fontSize: '10px', opacity: 0.9, fontWeight: 700 }}>Cleared</span>
                  </div>
                </div>
              </div>

              {/* 3 Labeled Legend Columns below */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px', borderTop: '1px solid #F1F5F9', paddingTop: '0.85rem' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11px', color: '#64748B' }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#C2410C' }} />
                    <span>Blockers</span>
                  </div>
                  <div style={{ fontSize: '13px', fontWeight: 800, color: '#C2410C', marginTop: '2px' }}>{blockersCount}</div>
                </div>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11px', color: '#64748B' }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#ED7D31' }} />
                    <span>In Review</span>
                  </div>
                  <div style={{ fontSize: '13px', fontWeight: 800, color: '#ED7D31', marginTop: '2px' }}>{inReviewCount}</div>
                </div>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11px', color: '#64748B' }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#FB923C' }} />
                    <span>Cleared</span>
                  </div>
                  <div style={{ fontSize: '13px', fontWeight: 800, color: '#16A34A', marginTop: '2px' }}>{verifiedCount}</div>
                </div>
              </div>
            </div>

            {/* CARD 3: Governance Dimensions (Spans 4 columns) */}
            <div style={{
              gridColumn: 'span 4',
              background: '#FFFFFF',
              borderRadius: '24px',
              padding: '1.75rem',
              boxShadow: '0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)',
              border: '1px solid rgba(226, 232, 240, 0.8)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              minHeight: '260px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>
                  Governance Dimensions
                </h3>
                <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#F8FAFC', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <ArrowUpRight size={13} color="#64748B" />
                </div>
              </div>

              {/* Dimension bars breakdown */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {(project.category_scores || categories.map(c => ({ category: c, score: 0, verified: 0, total: 1 }))).slice(0, 4).map((cat, idx) => {
                  const isSelected = selectedCategory === cat.category;
                  return (
                    <div
                      key={idx}
                      onClick={() => setSelectedCategory(isSelected ? 'ALL' : cat.category)}
                      style={{ cursor: 'pointer' }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', fontWeight: 600, marginBottom: '3px' }}>
                        <span style={{ color: isSelected ? '#ED7D31' : '#0F172A' }}>{cat.category}</span>
                        <span style={{ color: cat.score >= 90 ? '#16A34A' : cat.score > 0 ? '#ED7D31' : '#64748B', fontWeight: 700 }}>
                          {cat.score}% ({cat.verified}/{cat.total})
                        </span>
                      </div>
                      <div style={{ width: '100%', height: '6px', background: '#F1F5F9', borderRadius: '9999px', overflow: 'hidden' }}>
                        <div style={{
                          width: `${cat.score}%`,
                          height: '100%',
                          borderRadius: '9999px',
                          background: cat.score >= 90 ? '#16A34A' : '#ED7D31',
                          transition: 'width 0.4s ease'
                        }} />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#94A3B8', marginTop: '0.75rem', fontWeight: 600 }}>
                <span>{categories.length} Dimensions Tracked</span>
                {selectedCategory !== 'ALL' && (
                  <button
                    onClick={() => setSelectedCategory('ALL')}
                    style={{ background: 'none', border: 'none', color: '#ED7D31', fontSize: '11px', fontWeight: 700, cursor: 'pointer', padding: 0 }}
                  >
                    Reset Filter ✕
                  </button>
                )}
              </div>
            </div>

            {/* CARD 4: Sprint Horizon Bar Chart (Spans 4 columns) */}
            <div style={{
              gridColumn: 'span 4',
              background: '#FFFFFF',
              borderRadius: '24px',
              padding: '1.75rem',
              boxShadow: '0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)',
              border: '1px solid rgba(226, 232, 240, 0.8)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              minHeight: '260px'
            }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>
                    Sprint Horizon
                  </h3>
                  <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#F8FAFC', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Calendar size={13} color="#64748B" />
                  </div>
                </div>

                <div style={{ marginTop: '0.4rem' }}>
                  <span style={{ fontSize: '11px', color: '#64748B', fontWeight: 600, textTransform: 'uppercase' }}>Readiness Score</span>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0F172A' }}>
                    {project.score}%
                  </div>
                </div>
              </div>

              {/* 7 Vertical Bar Columns with one highlighted in orange matching reference image! */}
              <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', height: '100px', marginTop: '0.5rem', paddingBottom: '4px' }}>
                {[
                  { day: 'S1', height: '40%', active: false },
                  { day: 'S2', height: '55%', active: false },
                  { day: 'S3', height: '35%', active: false },
                  { day: 'S4', height: '85%', active: true, badge: `${project.score}%` },
                  { day: 'S5', height: '45%', active: false },
                  { day: 'S6', height: '60%', active: false },
                  { day: 'S7', height: '50%', active: false }
                ].map((bar, bIdx) => (
                  <div key={bIdx} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', flex: 1 }}>
                    {bar.active && (
                      <span style={{
                        background: '#ED7D31',
                        color: '#FFFFFF',
                        fontSize: '9.5px',
                        fontWeight: 800,
                        padding: '1px 5px',
                        borderRadius: '9999px',
                        marginBottom: '-2px'
                      }}>
                        {bar.badge}
                      </span>
                    )}
                    <div style={{
                      width: '24px',
                      height: bar.height,
                      borderRadius: '8px',
                      background: bar.active ? '#ED7D31' : '#EEF0F3',
                      boxShadow: bar.active ? '0 2px 6px rgba(237, 125, 49, 0.3)' : 'none',
                      transition: 'height 0.3s ease'
                    }} />
                    <span style={{ fontSize: '10.5px', color: bar.active ? '#ED7D31' : '#94A3B8', fontWeight: 700 }}>
                      {bar.day}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* CARD 5: Governance Sign-off & Audit (Spans 4 columns) */}
            <div style={{
              gridColumn: 'span 4',
              background: '#FFFFFF',
              borderRadius: '24px',
              padding: '1.75rem',
              boxShadow: '0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)',
              border: '1px solid rgba(226, 232, 240, 0.8)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              minHeight: '260px'
            }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>
                    Governance Audit
                  </h3>
                  <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#F8FAFC', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <ShieldCheck size={13} color="#ED7D31" />
                  </div>
                </div>

                <div style={{ marginTop: '0.65rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '1.4rem', fontWeight: 800, color: isInternalApproved ? '#16A34A' : '#0F172A' }}>
                      {isInternalApproved ? '100% Cleared' : 'Internal Review'}
                    </span>
                    <span style={{
                      background: isInternalApproved ? '#DCFCE7' : '#FFF7ED',
                      color: isInternalApproved ? '#166534' : '#EA580C',
                      fontSize: '11px',
                      fontWeight: 700,
                      padding: '2px 8px',
                      borderRadius: '9999px'
                    }}>
                      {isInternalApproved ? 'Akshay & Thasleema ✓' : 'Review Required'}
                    </span>
                  </div>
                  <p style={{ fontSize: '12px', color: '#64748B', margin: '0.4rem 0 0 0', lineHeight: 1.45 }}>
                    {isInternalApproved
                      ? 'Pre-Req Tracker signed and cleared for external engagement.'
                      : 'Akshay & Thasleema sign-off required prior to client sharing.'}
                  </p>
                </div>
              </div>

              <div style={{ borderTop: '1px solid #F1F5F9', paddingTop: '0.85rem' }}>
                {!isInternalApproved ? (
                  <button
                    type="button"
                    onClick={handleInternalSignoff}
                    disabled={internalSignoffLoading}
                    style={{
                      width: '100%',
                      background: '#0F172A',
                      color: '#FFFFFF',
                      border: 'none',
                      borderRadius: '9999px',
                      padding: '8px 14px',
                      fontSize: '12px',
                      fontWeight: 700,
                      cursor: internalSignoffLoading ? 'not-allowed' : 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '6px',
                      transition: 'all 0.15s ease'
                    }}
                    onMouseOver={(e) => { e.currentTarget.style.background = '#ED7D31'; }}
                    onMouseOut={(e) => { e.currentTarget.style.background = '#0F172A'; }}
                  >
                    <ShieldCheck size={14} color="#ED7D31" />
                    <span>{internalSignoffLoading ? 'Signing off...' : 'Sign Off (Akshay & Thasleema)'}</span>
                  </button>
                ) : (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '11.5px', color: '#166534', fontWeight: 700 }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                      <Check size={13} strokeWidth={3} /> Verified by Akshay & Thasleema
                    </span>
                    <span style={{ color: '#64748B', fontWeight: 500 }}>Audit ID #941</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* PREREQUISITES & DELIVERABLES (100% TABLE-FREE!) */}
          <div style={{ marginTop: '1rem' }}>
            {/* Header & View Switcher */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '1.25rem',
              flexWrap: 'wrap',
              gap: '1rem'
            }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', margin: 0, fontWeight: 800, color: '#0F172A', letterSpacing: '-0.02em' }}>
                  {dashboardView === 'PLANNER' ? 'Weekly Sprint Planner' : 'Prerequisites & Milestones'}
                </h2>
                <p style={{ color: '#64748B', fontSize: '13px', margin: '0.25rem 0 0' }}>
                  {dashboardView === 'PLANNER'
                    ? 'Sprint delivery alignment mapped directly to technical prerequisites.'
                    : 'Interactive milestone cards — click any circle to verify or inspect evidence directly.'}
                </p>
              </div>

              {/* View Switcher Pill Tabs */}
              <div style={{
                background: '#FFFFFF',
                borderRadius: '9999px',
                border: '1px solid #E2E8F0',
                padding: '4px',
                display: 'flex',
                gap: '4px',
                boxShadow: '0 1px 3px rgba(15, 23, 42, 0.04)'
              }}>
                <button
                  type="button"
                  onClick={() => setDashboardView('SIMPLE')}
                  style={{
                    background: dashboardView === 'SIMPLE' ? '#0F172A' : 'transparent',
                    color: dashboardView === 'SIMPLE' ? '#FFFFFF' : '#64748B',
                    border: 'none',
                    borderRadius: '9999px',
                    padding: '6px 16px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <Zap size={13} color={dashboardView === 'SIMPLE' ? '#ED7D31' : '#64748B'} />
                  <span>Cards Feed</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDashboardView('MATRIX')}
                  style={{
                    background: dashboardView === 'MATRIX' ? '#0F172A' : 'transparent',
                    color: dashboardView === 'MATRIX' ? '#FFFFFF' : '#64748B',
                    border: 'none',
                    borderRadius: '9999px',
                    padding: '6px 16px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <LayoutGrid size={13} color={dashboardView === 'MATRIX' ? '#ED7D31' : '#64748B'} />
                  <span>2-Col Grid</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDashboardView('PLANNER')}
                  style={{
                    background: dashboardView === 'PLANNER' ? '#0F172A' : 'transparent',
                    color: dashboardView === 'PLANNER' ? '#FFFFFF' : '#64748B',
                    border: 'none',
                    borderRadius: '9999px',
                    padding: '6px 16px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <Calendar size={13} color={dashboardView === 'PLANNER' ? '#ED7D31' : '#64748B'} />
                  <span>Weekly Planner</span>
                </button>
              </div>
            </div>

            {/* If Planner view is selected */}
            {dashboardView === 'PLANNER' ? (
              <WeeklyPlanner
                checklist={checklist}
                project={project}
                onProvideHandover={(item) => setSubmitModalItem(item)}
                onToggleCheck={handleToggleCheck}
              />
            ) : (
              <div>
                {/* Filter Toolbar with Pill Buttons */}
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: '8px',
                  marginBottom: '1.25rem'
                }}>
                  {/* Status Pills */}
                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                    <button
                      onClick={() => { setSelectedStatus('ALL'); setOnlyCritical(false); }}
                      style={{
                        background: selectedStatus === 'ALL' && !onlyCritical ? '#0F172A' : '#FFFFFF',
                        color: selectedStatus === 'ALL' && !onlyCritical ? '#FFFFFF' : '#475569',
                        border: '1px solid',
                        borderColor: selectedStatus === 'ALL' && !onlyCritical ? '#0F172A' : '#E2E8F0',
                        borderRadius: '9999px',
                        padding: '6px 14px',
                        fontSize: '12px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      All ({checklist.length})
                    </button>

                    <button
                      onClick={() => { setOnlyCritical(true); setSelectedStatus('ALL'); }}
                      style={{
                        background: onlyCritical ? '#FEF2F2' : '#FFFFFF',
                        color: '#DC2626',
                        border: '1px solid',
                        borderColor: onlyCritical ? '#DC2626' : '#FECACA',
                        borderRadius: '9999px',
                        padding: '6px 14px',
                        fontSize: '12px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px',
                        boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      <AlertTriangle size={13} color="#DC2626" />
                      <span>Critical Blockers ({blockersCount})</span>
                    </button>

                    <button
                      onClick={() => { setSelectedStatus('Submitted'); setOnlyCritical(false); }}
                      style={{
                        background: selectedStatus === 'Submitted' ? '#FFF7ED' : '#FFFFFF',
                        color: '#EA580C',
                        border: '1px solid',
                        borderColor: selectedStatus === 'Submitted' ? '#EA580C' : '#FED7AA',
                        borderRadius: '9999px',
                        padding: '6px 14px',
                        fontSize: '12px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px',
                        boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      <Clock size={13} color="#EA580C" />
                      <span>In Review ({inReviewCount})</span>
                    </button>

                    <button
                      onClick={() => { setSelectedStatus('Pending'); setOnlyCritical(false); }}
                      style={{
                        background: selectedStatus === 'Pending' ? '#0F172A' : '#FFFFFF',
                        color: selectedStatus === 'Pending' ? '#FFFFFF' : '#475569',
                        border: '1px solid',
                        borderColor: selectedStatus === 'Pending' ? '#0F172A' : '#E2E8F0',
                        borderRadius: '9999px',
                        padding: '6px 14px',
                        fontSize: '12px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px',
                        boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      <ListChecks size={13} color={selectedStatus === 'Pending' ? '#FFFFFF' : '#64748B'} />
                      <span>To Do ({pendingCount})</span>
                    </button>

                    <button
                      onClick={() => { setSelectedStatus('Verified'); setOnlyCritical(false); }}
                      style={{
                        background: selectedStatus === 'Verified' ? '#F0FDF4' : '#FFFFFF',
                        color: '#166534',
                        border: '1px solid',
                        borderColor: selectedStatus === 'Verified' ? '#166534' : '#BBF7D0',
                        borderRadius: '9999px',
                        padding: '6px 14px',
                        fontSize: '12px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px',
                        boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      <CheckCircle2 size={13} color="#166534" />
                      <span>Verified ({verifiedCount})</span>
                    </button>
                  </div>

                  {/* Search Input Pill */}
                  <div style={{ position: 'relative', minWidth: '240px' }}>
                    <Search size={14} color="#94A3B8" style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)' }} />
                    <input
                      type="text"
                      placeholder="Search milestones..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      style={{
                        padding: '8px 14px 8px 36px',
                        borderRadius: '9999px',
                        border: '1px solid #E2E8F0',
                        fontSize: '12.5px',
                        outline: 'none',
                        width: '100%',
                        background: '#FFFFFF',
                        color: '#0F172A',
                        boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                        transition: 'all 0.15s ease'
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = '#ED7D31';
                        e.currentTarget.style.boxShadow = '0 0 0 3px rgba(237, 125, 49, 0.12)';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = '#E2E8F0';
                        e.currentTarget.style.boxShadow = '0 1px 2px rgba(15, 23, 42, 0.04)';
                      }}
                    />
                  </div>
                </div>

                {/* TABLE-FREE MILESTONE CARDS (Rendered as clean floating cards) */}
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: dashboardView === 'MATRIX' ? 'repeat(auto-fit, minmax(460px, 1fr))' : '1fr',
                  gap: '1rem'
                }}>
                  {filteredItems.map((item) => {
                    const isVerified = item.status === 'Verified';
                    const isSubmitted = item.status === 'Submitted' || item.status === 'Verifying';
                    const isVerifying = verifyingId === item.id;
                    const isExpanded = expandedItemId === item.id;

                    return (
                      <div
                        key={item.id}
                        style={{
                          background: '#FFFFFF',
                          borderRadius: '20px',
                          border: item.is_critical && !isVerified ? '1px solid #FED7AA' : '1px solid #E2E8F0',
                          padding: '1.25rem 1.5rem',
                          boxShadow: '0 2px 10px -2px rgba(15, 23, 42, 0.03)',
                          transition: 'all 0.15s ease',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '0.85rem'
                        }}
                      >
                        {/* Card Top: Check Circle + Title + Status Badges */}
                        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '12px' }}>
                          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', flex: 1, minWidth: 0 }}>
                            {/* Circular Toggle Button */}
                            <button
                              type="button"
                              onClick={(e) => handleToggleCheck(e, item)}
                              style={{
                                width: '24px',
                                height: '24px',
                                borderRadius: '50%',
                                background: isVerified ? '#16A34A' : isSubmitted ? '#FFF7ED' : '#FFFFFF',
                                border: isVerified ? 'none' : isSubmitted ? '2px solid #ED7D31' : item.is_critical ? '2px solid #ED7D31' : '2px solid #CBD5E1',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                flexShrink: 0,
                                marginTop: '2px',
                                transition: 'all 0.15s ease',
                                boxShadow: isVerified ? '0 2px 6px rgba(22, 163, 74, 0.3)' : 'none'
                              }}
                              title={isVerified ? "Mark as Pending" : "Mark as Verified"}
                            >
                              {isVerified && <Check size={14} color="#FFFFFF" strokeWidth={3} />}
                              {isSubmitted && !isVerified && <Clock size={12} color="#EA580C" />}
                            </button>

                            {/* Title & Metadata Badges */}
                            <div style={{ minWidth: 0, flex: 1 }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', marginBottom: '4px' }}>
                                {/* Category Pill */}
                                <span style={{
                                  background: '#F1F5F9',
                                  color: '#475569',
                                  fontSize: '11px',
                                  fontWeight: 700,
                                  padding: '2px 8px',
                                  borderRadius: '9999px'
                                }}>
                                  {item.category || 'General'}
                                </span>

                                {item.is_critical && (
                                  <span style={{
                                    background: '#FEF2F2',
                                    color: '#DC2626',
                                    border: '1px solid #FECACA',
                                    fontSize: '11px',
                                    fontWeight: 700,
                                    padding: '2px 8px',
                                    borderRadius: '9999px',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '4px'
                                  }}>
                                    <AlertTriangle size={11} /> Critical Gatekeeper
                                  </span>
                                )}

                                {item.has_api_key && (
                                  <button
                                    type="button"
                                    onClick={(e) => { e.stopPropagation(); setViewProofModalItem(item); }}
                                    style={{
                                      background: '#F8FAFC',
                                      color: '#0F172A',
                                      border: '1px solid #CBD5E1',
                                      fontSize: '11px',
                                      fontWeight: 700,
                                      padding: '2px 8px',
                                      borderRadius: '9999px',
                                      cursor: 'pointer',
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: '4px'
                                    }}
                                  >
                                    <Key size={11} color="#ED7D31" /> Masked Credential
                                  </button>
                                )}

                                {item.evidence_file && (
                                  <button
                                    type="button"
                                    onClick={(e) => { e.stopPropagation(); setViewProofModalItem(item); }}
                                    style={{
                                      background: '#FFF7ED',
                                      color: '#ED7D31',
                                      border: '1px solid #FFEDD5',
                                      fontSize: '11px',
                                      fontWeight: 700,
                                      padding: '2px 8px',
                                      borderRadius: '9999px',
                                      cursor: 'pointer',
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: '4px'
                                    }}
                                  >
                                    <FileText size={11} /> Proof Attached
                                  </button>
                                )}
                              </div>

                              <div style={{
                                fontSize: '14.5px',
                                fontWeight: 700,
                                color: isVerified ? '#64748B' : '#0F172A',
                                textDecoration: isVerified ? 'line-through' : 'none',
                                lineHeight: 1.3
                              }}>
                                {item.name}
                              </div>
                            </div>
                          </div>

                          {/* Status Pill Badge */}
                          <div style={{ flexShrink: 0 }}>
                            {isVerified ? (
                              <span style={{
                                background: '#F0FDF4',
                                color: '#166534',
                                border: '1px solid #BBF7D0',
                                padding: '3px 10px',
                                borderRadius: '9999px',
                                fontSize: '11px',
                                fontWeight: 700,
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '5px'
                              }}>
                                <CheckCircle2 size={12} /> Verified
                              </span>
                            ) : isSubmitted ? (
                              <span style={{
                                background: '#FFF7ED',
                                color: '#EA580C',
                                border: '1px solid #FED7AA',
                                padding: '3px 10px',
                                borderRadius: '9999px',
                                fontSize: '11px',
                                fontWeight: 700,
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '5px'
                              }}>
                                <Clock size={12} /> In Review
                              </span>
                            ) : (
                              <span style={{
                                background: '#F1F5F9',
                                color: '#475569',
                                border: '1px solid #E2E8F0',
                                padding: '3px 10px',
                                borderRadius: '9999px',
                                fontSize: '11px',
                                fontWeight: 600,
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '5px'
                              }}>
                                <Clock size={12} /> Pending
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Description */}
                        <div style={{ fontSize: '13px', color: '#475569', lineHeight: 1.5 }}>
                          {item.description}
                        </div>

                        {/* Rejection Alert if any */}
                        {item.rejection_reason && (
                          <div style={{ background: '#FEF2F2', border: '1px solid #FECACA', color: '#DC2626', padding: '6px 12px', borderRadius: '12px', fontSize: '12px' }}>
                            <strong>Rejection Note:</strong> {item.rejection_reason}
                          </div>
                        )}

                        {/* Card Bottom: Metadata on Left + Pill Action Buttons on Right */}
                        <div style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          borderTop: '1px solid #F1F5F9',
                          paddingTop: '0.75rem',
                          flexWrap: 'wrap',
                          gap: '10px'
                        }}>
                          {/* Owner & Due info */}
                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '12px', color: '#64748B' }}>
                            <span>Owner: <strong style={{ color: '#0F172A' }}>{item.owner || 'Client Tech Lead'}</strong></span>
                            {item.due_date && (
                              <>
                                <span>•</span>
                                <span>Due: <strong style={{ color: '#0F172A' }}>{item.due_date}</strong></span>
                              </>
                            )}
                          </div>

                          {/* Pill Action Buttons */}
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                            {/* Inspect Proof Button */}
                            {(isSubmitted || isVerified || item.evidence_file || item.evidence_notes || item.has_api_key) && (
                              <button
                                type="button"
                                onClick={() => setViewProofModalItem(item)}
                                style={{
                                  background: '#FFFFFF',
                                  color: '#0F172A',
                                  border: '1px solid #E2E8F0',
                                  borderRadius: '9999px',
                                  padding: '5px 14px',
                                  fontSize: '11.5px',
                                  fontWeight: 600,
                                  cursor: 'pointer',
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  gap: '5px',
                                  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                                  transition: 'all 0.15s ease'
                                }}
                                onMouseOver={(e) => { e.currentTarget.style.borderColor = '#CBD5E1'; }}
                                onMouseOut={(e) => { e.currentTarget.style.borderColor = '#E2E8F0'; }}
                              >
                                <Eye size={12} color="#64748B" />
                                <span>Inspect Proof</span>
                              </button>
                            )}

                            {/* Verify & AI Verify buttons if in review */}
                            {isSubmitted && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleManualVerify(item.id)}
                                  style={{
                                    background: '#ED7D31',
                                    color: '#FFFFFF',
                                    border: 'none',
                                    borderRadius: '9999px',
                                    padding: '5px 14px',
                                    fontSize: '11.5px',
                                    fontWeight: 700,
                                    cursor: 'pointer',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '5px'
                                  }}
                                  onMouseOver={(e) => { e.currentTarget.style.background = '#EA580C'; }}
                                  onMouseOut={(e) => { e.currentTarget.style.background = '#ED7D31'; }}
                                >
                                  <Check size={12} strokeWidth={2.5} />
                                  <span>Verify</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleAiVerify(item.id)}
                                  disabled={isVerifying}
                                  style={{
                                    background: '#FFFFFF',
                                    color: '#ED7D31',
                                    border: '1px solid #FED7AA',
                                    borderRadius: '9999px',
                                    padding: '5px 12px',
                                    fontSize: '11.5px',
                                    fontWeight: 700,
                                    cursor: 'pointer',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '4px'
                                  }}
                                >
                                  {isVerifying ? <Loader2 className="animate-spin" size={12} /> : <Sparkles size={12} />}
                                  <span>AI Verify</span>
                                </button>
                              </>
                            )}

                            {/* Submit Evidence Button if not cleared & not in review */}
                            {!isVerified && !isSubmitted && (
                              <button
                                type="button"
                                onClick={() => setSubmitModalItem(item)}
                                style={{
                                  background: '#0F172A',
                                  color: '#FFFFFF',
                                  border: 'none',
                                  borderRadius: '9999px',
                                  padding: '5px 14px',
                                  fontSize: '11.5px',
                                  fontWeight: 600,
                                  cursor: 'pointer',
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  gap: '5px',
                                  transition: 'all 0.15s ease'
                                }}
                                onMouseOver={(e) => { e.currentTarget.style.background = '#ED7D31'; }}
                                onMouseOut={(e) => { e.currentTarget.style.background = '#0F172A'; }}
                              >
                                <Upload size={12} />
                                <span>Submit</span>
                              </button>
                            )}

                            {/* Nudge Owner Icon Pill */}
                            {!isVerified && (
                              <button
                                type="button"
                                onClick={() => setEscalateModalItem(item)}
                                style={{
                                  background: '#FFF7ED',
                                  border: '1px solid #FFEDD5',
                                  borderRadius: '9999px',
                                  padding: '5px 10px',
                                  cursor: 'pointer',
                                  color: '#ED7D31',
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  transition: 'all 0.15s ease'
                                }}
                                title="Send Nudge to Deliverable Owner"
                              >
                                <Send size={12} />
                              </button>
                            )}

                            {/* Reset Button if verified */}
                            {isVerified && (
                              <button
                                type="button"
                                onClick={(e) => handleToggleCheck(e, item)}
                                style={{
                                  background: '#F4F4F5',
                                  border: '1px solid #E4E4E7',
                                  borderRadius: '9999px',
                                  padding: '4px 12px',
                                  fontSize: '11px',
                                  fontWeight: 600,
                                  color: '#18181B',
                                  cursor: 'pointer'
                                }}
                              >
                                Reset
                              </button>
                            )}

                            {/* Expand Drawer Button */}
                            <button
                              type="button"
                              onClick={() => setExpandedItemId(isExpanded ? null : item.id)}
                              style={{
                                background: '#F8FAFC',
                                border: '1px solid #E2E8F0',
                                borderRadius: '9999px',
                                padding: '4px 8px',
                                cursor: 'pointer',
                                color: '#64748B',
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                              }}
                              title={isExpanded ? "Collapse details" : "Expand details"}
                            >
                              {isExpanded ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                            </button>
                          </div>
                        </div>

                        {/* Inline Drawer for Expanded Details */}
                        {isExpanded && (
                          <div style={{
                            background: '#F8FAFC',
                            borderRadius: '16px',
                            border: '1px solid #E2E8F0',
                            padding: '1.25rem',
                            marginTop: '0.25rem',
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
                            gap: '1.25rem'
                          }}>
                            <div>
                              <div style={{ fontSize: '11px', fontWeight: 800, color: '#ED7D31', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '4px' }}>
                                Deliverable Standard
                              </div>
                              <div style={{ fontSize: '12.5px', color: '#334155', lineHeight: 1.5 }}>
                                {item.expected_evidence || 'Structured handover artifact, access credential, or architecture sign-off required.'}
                              </div>

                              {item.evidence_notes && (
                                <div style={{ marginTop: '0.65rem' }}>
                                  <div style={{ fontSize: '11px', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', marginBottom: '2px' }}>
                                    Technical Notes:
                                  </div>
                                  <div style={{ fontSize: '12px', color: '#475569', background: '#FFFFFF', padding: '6px 10px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
                                    {item.evidence_notes}
                                  </div>
                                </div>
                              )}
                            </div>

                            <div>
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                                <div style={{ fontSize: '11px', fontWeight: 800, color: '#ED7D31', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                                  Verification Artifact
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setViewProofModalItem(item)}
                                  style={{
                                    background: '#0F172A',
                                    color: '#FFFFFF',
                                    border: 'none',
                                    borderRadius: '9999px',
                                    padding: '3px 12px',
                                    fontSize: '11px',
                                    fontWeight: 700,
                                    cursor: 'pointer',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '4px'
                                  }}
                                >
                                  <Eye size={11} /> Inspect Proof Modal ↗
                                </button>
                              </div>

                              {item.has_api_key && (
                                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '0.5rem', flexWrap: 'wrap' }}>
                                  <span style={{ fontSize: '12px', fontWeight: 600, color: '#0F172A' }}>Credential:</span>
                                  <code style={{ background: '#FFFFFF', border: '1px solid #CBD5E1', padding: '2px 8px', borderRadius: '6px', fontSize: '11.5px', color: '#0F172A', fontFamily: 'monospace' }}>
                                    {item.masked_api_key}
                                  </code>
                                  <span style={{ fontSize: '11px', color: '#16A34A', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
                                    <ShieldCheck size={12} /> Secure
                                  </span>
                                </div>
                              )}

                              {item.evidence_file && (
                                <div style={{ marginTop: '0.5rem' }}>
                                  <div style={{ fontSize: '11px', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', marginBottom: '4px' }}>
                                    Uploaded Screenshots & Files:
                                  </div>
                                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                                    {item.evidence_file.split(',').map((fPath, fIdx) => {
                                      const clean = fPath.trim();
                                      if (!clean) return null;
                                      const fullUrl = clean.startsWith('http') ? clean : `${BASE_URL}${clean}`;
                                      const isImg = /\.(png|jpe?g|webp|gif|svg)$/i.test(clean);
                                      const fname = clean.split('/').pop();
                                      return (
                                        <div key={fIdx} style={{
                                          border: '1px solid #E2E8F0',
                                          borderRadius: '8px',
                                          padding: '6px 10px',
                                          background: '#FFFFFF',
                                          display: 'flex',
                                          alignItems: 'center',
                                          gap: '8px',
                                          maxWidth: '280px'
                                        }}>
                                          {isImg ? (
                                            <a href={fullUrl} target="_blank" rel="noreferrer">
                                              <img src={fullUrl} alt={fname} style={{ width: '40px', height: '40px', objectFit: 'cover', borderRadius: '6px', border: '1px solid #CBD5E1' }} />
                                            </a>
                                          ) : (
                                            <FileText size={20} color="#ED7D31" />
                                          )}
                                          <div style={{ minWidth: 0, overflow: 'hidden' }}>
                                            <div style={{ fontSize: '11.5px', fontWeight: 700, color: '#0F172A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{fname}</div>
                                            <a href={fullUrl} target="_blank" rel="noreferrer" style={{ fontSize: '11px', color: '#ED7D31', fontWeight: 600 }}>
                                              {isImg ? 'Open Screenshot' : 'Download File'}
                                            </a>
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              )}

                              {item.verification_notes && (
                                <div style={{ marginTop: '0.65rem', padding: '6px 10px', background: '#F0FDF4', border: '1px solid #BBF7D0', borderRadius: '8px', fontSize: '12px', color: '#166534' }}>
                                  <strong>AI Evaluation:</strong> {item.verification_notes}
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}

                  {filteredItems.length === 0 && (
                    <div style={{
                      background: '#FFFFFF',
                      borderRadius: '20px',
                      padding: '3rem 1.5rem',
                      textAlign: 'center',
                      border: '1px solid #E2E8F0',
                      color: '#64748B'
                    }}>
                      {project?.analysis_status === 'FAILED' ? (
                        <div>
                          <div style={{ fontWeight: 700, color: '#DC2626', fontSize: '15px', marginBottom: '6px' }}>AI SOW Analysis Failed</div>
                          <div style={{ fontSize: '13px', color: '#64748B', maxWidth: '500px', margin: '0 auto 16px auto', lineHeight: 1.5 }}>
                            {project.analysis_error || 'Prerequisites could not be generated. Use the Reanalyze button to retry extraction.'}
                          </div>
                          <button
                            type="button"
                            onClick={handleRetryAnalysis}
                            disabled={reanalyzing}
                            style={{
                              background: '#0F172A',
                              color: '#FFFFFF',
                              border: 'none',
                              borderRadius: '9999px',
                              padding: '8px 20px',
                              fontSize: '12.5px',
                              fontWeight: 600,
                              cursor: reanalyzing ? 'not-allowed' : 'pointer',
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '6px'
                            }}
                          >
                            <RefreshCw size={13} className={reanalyzing ? 'animate-spin' : ''} />
                            <span>{reanalyzing ? 'Reanalyzing...' : 'Retry SOW Analysis'}</span>
                          </button>
                        </div>
                      ) : checklist.length === 0 ? (
                        <div>
                          <div style={{ fontWeight: 700, color: '#334155', fontSize: '15px', marginBottom: '6px' }}>No Prerequisites Extracted</div>
                          <div style={{ fontSize: '13px', color: '#94A3B8', maxWidth: '500px', margin: '0 auto', lineHeight: 1.5 }}>
                            The document analysis completed, but no explicit client prerequisites were identified in the source text.
                          </div>
                        </div>
                      ) : (
                        <div>No prerequisites match your current filters.</div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Modals */}
      <ViewProofModal
        isOpen={!!viewProofModalItem}
        item={viewProofModalItem}
        project={project}
        onClose={() => setViewProofModalItem(null)}
        onUpdated={fetchProjectData}
        onOpenRejectModal={(it) => setRejectModalItem(it)}
      />

      <SubmitEvidenceModal
        isOpen={!!submitModalItem}
        onClose={() => setSubmitModalItem(null)}
        item={submitModalItem}
        onSubmitted={fetchProjectData}
      />

      <AddItemModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        projectId={id}
        existingItems={checklist}
        onItemAdded={fetchProjectData}
      />

      <EscalateModal
        isOpen={!!escalateModalItem}
        onClose={() => setEscalateModalItem(null)}
        item={escalateModalItem}
        onEscalated={fetchProjectData}
      />

      <RejectModal
        isOpen={!!rejectModalItem}
        onClose={() => setRejectModalItem(null)}
        item={rejectModalItem}
        onRejected={fetchProjectData}
      />

      {isBrdModalOpen && (
        <BRDViewerModal
          projectId={id}
          projectName={project.name}
          onClose={() => setIsBrdModalOpen(false)}
        />
      )}
    </div>
  );
};
